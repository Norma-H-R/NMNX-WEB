import{F as e,H as t,L as n,M as r,N as i,V as a,Y as o,_ as s,_t as c,ht as l,i as u,k as d,l as f,p,t as m,u as h,v as g,vt as _}from"./BTiICJCj.js";import{r as v}from"#entry";var y=3,b=1,x=7,S=.18,C=.5,w=4,T=.705,E=.08,D=.3185,O=1,k=.3,A=1.3,j=.8,M=1,N=.5,P=`#version 300 es
layout(location = 0) in vec2 aPos;
void main() { gl_Position = vec4(aPos, 0.0, 1.0); }`,F=`#version 300 es
precision highp float;
out vec4 fragColor;

uniform vec2 uRes;
uniform float uTime;
uniform float uSpeed;
uniform float uDensity;
uniform float uFrequency;
uniform vec3 uColor1;
uniform vec3 uColor2;

vec2 hash( vec2 p ) {
  p = vec2(dot(p,vec2(127.1,311.7)), dot(p,vec2(269.5,183.3)));
  return -1.0 + 2.0 * fract(sin(p) * 43758.5453123);
}

float noise(vec2 p) {
  const float K1 = 0.366025404;
  const float K2 = 0.211324865;
  vec2 i = floor(p + (p.x + p.y) * K1);
  vec2 a = p - i + (i.x + i.y) * K2;
  vec2 o = (a.x > a.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
  vec2 b = a - o + K2;
  vec2 c = a - 1.0 + 2.0 * K2;
  vec3 h = max(0.5 - vec3(dot(a,a), dot(b,b), dot(c,c)), 0.0);
  vec3 n = h*h*h*h * vec3(dot(a, hash(i+0.0)), dot(b, hash(i+o)), dot(c, hash(i+1.0)));
  return dot(n, vec3(70.0));
}

float fbm(vec2 p) {
  float value = 0.0;
  float amplitude = 0.5;
  float frequency = 1.0;
  for (int i = 0; i < 3; i++) {
    value += amplitude * noise(p * frequency);
    frequency *= 2.0;
    amplitude *= 0.5;
  }
  return value * 0.5 + 0.5;
}

void main() {
  vec2 st = gl_FragCoord.xy / uRes;
  float t = uTime * uSpeed;
  vec2 q = vec2(
    fbm(st * uDensity + vec2(0.0, 0.2 * t)),
    fbm(st * uDensity + vec2(1.2, -0.3 * t))
  );
  float n = fbm(st * uDensity + q * uFrequency);
  vec3 color = mix(uColor1, uColor2, n);
  fragColor = vec4(color, 1.0);
}`,I=m({__name:`DotMatrix`,setup(e){let t=4/x,n=[.06,.15,.45],a=[1,1,1],s=35*t,c=[110/255,231/255,1].map(e=>e*j),l=[1,1,1].map(e=>e*M),u=[6/255,7/255,13/255],f=`#version 300 es
precision highp float;
out vec4 fragColor;

uniform sampler2D uFluid;
uniform vec2 uRes;
uniform float uTime;
uniform vec2 uMouse;
uniform float uMouseRadius;
uniform float uMouseStrength;

// 这三个都已经是"画布像素"单位（几何取整数、流场幅度已按倍率换算）
#define PIX ${y.toFixed(3)}
#define GAP ${b.toFixed(3)}
#define FLOW_AMP ${s.toFixed(3)}
#define THRESHOLD ${T.toFixed(4)}
#define JITTER ${E.toFixed(4)}
#define ACCENT_RATIO ${D.toFixed(4)}
#define COLOR_RATE ${O.toFixed(4)}
#define MOUSE_R ${k.toFixed(4)}
#define MOUSE_K ${A.toFixed(2)}
#define COL_ACCENT vec3(${c.map(e=>e.toFixed(4)).join(`,`)})
#define COL_WHITE vec3(${l.map(e=>e.toFixed(4)).join(`,`)})
#define COL_BG vec3(${u.map(e=>e.toFixed(5)).join(`,`)})

float e1Random(vec2 st) {
  return fract(sin(dot(st.xy, vec2(12.9898, 78.233))) * 43758.5453123);
}

vec2 e1Hash(vec2 p) {
  p = vec2(dot(p,vec2(127.1,311.7)), dot(p,vec2(269.5,183.3)));
  return -1.0 + 2.0 * fract(sin(p) * 43758.5453123);
}

float e1Noise(vec2 p) {
  const float K1 = 0.366025404;
  const float K2 = 0.211324865;
  vec2 i = floor(p + (p.x + p.y) * K1);
  vec2 a = p - i + (i.x + i.y) * K2;
  vec2 o = (a.x > a.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
  vec2 b = a - o + K2;
  vec2 c = a - 1.0 + 2.0 * K2;
  vec3 h = max(0.5 - vec3(dot(a,a), dot(b,b), dot(c,c)), 0.0);
  vec3 n = h*h*h*h * vec3(dot(a, e1Hash(i+0.0)), dot(b, e1Hash(i+o)), dot(c, e1Hash(i+1.0)));
  return dot(n, vec3(70.0));
}

float e1Fbm(vec2 p) {
  float value = 0.0;
  float amplitude = 0.5;
  float frequency = 1.0;
  for (int i = 0; i < 3; i++) {
    value += amplitude * e1Noise(p * frequency);
    frequency *= 2.0;
    amplitude *= 0.5;
  }
  return value * 0.5 + 0.5;
}

vec2 e1ComputeFluidFlow(vec2 uv, float time, float speed, float density, float frequency) {
  vec2 q = vec2(
    e1Fbm(uv * density + vec2(0.0, 0.2 * time * speed)),
    e1Fbm(uv * density + vec2(1.2, -0.3 * time * speed))
  );
  vec2 flowVector = vec2(q.x * 0.3, q.y * 0.7) * 2.0;
  flowVector.x *= 0.5;
  flowVector.y *= 1.5;
  return flowVector;
}

void main() {
  vec2 uv = gl_FragCoord.xy / uRes;

  float time = uTime;
  float speed = 0.15;
  float density = 1.5;
  float frequency = 2.5;

  vec2 pixelCoord = uv * uRes;
  float totalSize = PIX + GAP;
  vec2 blockId = floor(pixelCoord / totalSize);
  vec2 blockCenterUV = (blockId * totalSize + vec2(PIX / 2.0)) / uRes;

  vec2 flow = e1ComputeFluidFlow(blockCenterUV, time, speed, density, frequency) * FLOW_AMP;

  vec2 blockPos = blockId * totalSize;
  vec2 posInBlock = pixelCoord - blockPos;
  vec2 offsetBlockPos = blockPos - flow;

  // 间隙：先判再采样
  if (posInBlock.x > PIX || posInBlock.y > PIX) {
    fragColor = vec4(COL_BG, 1.0);
    return;
  }

  vec2 offsetBlockCenter = offsetBlockPos + vec2(PIX / 2.0);
  vec2 blockUv = offsetBlockCenter / uRes;
  vec4 color = texture(uFluid, blockUv);
  float brightness = (color.r + color.g + color.b) / 3.0;

  // 粒子身份 = **流动之后**的格位，而不是固定的屏幕格 blockId。
  // 原版这里是 e1Random(blockId)：种子绑在屏幕网格上，蓝/白于是成了**一层永远
  // 不动的固定网纹** —— 白云从上面流过时就成了"白色里透出一层固定的蓝"，看着
  // 就是蓝色是死的、只有白色在动。改成跟流动绑定的身份后，整个蓝白图案会跟着
  // 云一起流，蓝点自然就和白点一样在动。
  vec2 cellId = floor(offsetBlockPos / totalSize);

  // 亮度抖动：只按粒子身份取 → 一个亮着的点在它流动过程中保持稳定，不会原地闪
  float randJit = e1Random(cellId);

  // 颜色：同一个粒子身份再拌一个"每格相位错开"的时间项 → 过一会儿还会重掷一次
  // 颜色（COLOR_RATE=0 就纯随流、永不重掷）。蓝和白都是这样随机出现的，没有主次，
  // 更不是"先有白、白里再挑出蓝"。
  float rt = time * COLOR_RATE + e1Random(cellId + 0.5) * 37.0;
  float rc0 = e1Random(cellId + vec2(floor(rt), 0.0));
  float rc1 = e1Random(cellId + vec2(floor(rt) + 1.0, 0.0));
  // 硬切换，不做插值：rc0/rc1 本身是均匀分布，直接切换后取值依然均匀，
  // ACCENT_RATIO 才能线性对应到实际蓝点占比。
  // （用 mix 插值会把分布压向 0.5 —— 实测 ACCENT_RATIO=0.3185 只出 25.6% 蓝点，
  //  比设定少了 6 个百分点。换色节奏不受影响，仍然是每格约 1/COLOR_RATE 秒一次。）
  float randCol = fract(rt) < 0.5 ? rc0 : rc1;

  float dynamicThreshold = THRESHOLD - JITTER * randJit;

  float dist = distance(blockCenterUV, uMouse);
  float mouseFactor = (1.0 - smoothstep(0.0, MOUSE_R, dist)) * MOUSE_K;

  vec3 col = COL_BG;
  if (brightness > dynamicThreshold) {
    if (randCol < ACCENT_RATIO) {
      vec3 c = COL_ACCENT;
      if (mouseFactor > 0.0) c = mix(c, COL_WHITE, mouseFactor);
      col = c;
    } else {
      if (mouseFactor > 0.0) col = mix(COL_WHITE, COL_ACCENT, mouseFactor);
      else col = COL_WHITE;
    }
  }
  fragColor = vec4(col, 1.0);
}`,m=o(null),h=null,g=0,_=0,v=!1,I=null,L=null,R={},z={},B=null,V=null,H=null,U=0,W=0,G={tx:-10,ty:-10,x:-10,y:-10};function ee(e,t,n){let r=h.createShader(e);return h.shaderSource(r,t),h.compileShader(r),h.getShaderParameter(r,h.COMPILE_STATUS)?r:(console.error(`[DotMatrix] ${n} shader 编译失败:`,h.getShaderInfoLog(r)),null)}function te(e,t,n){let r=ee(h.VERTEX_SHADER,e,n+`/vert`),i=ee(h.FRAGMENT_SHADER,t,n+`/frag`);if(!r||!i)return null;let a=h.createProgram();return h.attachShader(a,r),h.attachShader(a,i),h.linkProgram(a),h.getProgramParameter(a,h.LINK_STATUS)?a:(console.error(`[DotMatrix] ${n} program 链接失败:`,h.getProgramInfoLog(a)),null)}function ne(e,t){let n={};for(let r of t)n[r]=h.getUniformLocation(e,r);return n}function re(){return h=m.value.getContext(`webgl2`,{antialias:!1,alpha:!1}),!h||(I=te(P,F,`fluid`),L=te(P,f,`pixel`),!I||!L)?!1:(R=ne(I,[`uRes`,`uTime`,`uSpeed`,`uDensity`,`uFrequency`,`uColor1`,`uColor2`]),z=ne(L,[`uFluid`,`uRes`,`uTime`,`uMouse`,`uMouseRadius`,`uMouseStrength`]),B=h.createBuffer(),h.bindBuffer(h.ARRAY_BUFFER,B),h.bufferData(h.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),h.STATIC_DRAW),h.enableVertexAttribArray(0),h.vertexAttribPointer(0,2,h.FLOAT,!1,0,0),H=h.createTexture(),h.bindTexture(h.TEXTURE_2D,H),h.texParameteri(h.TEXTURE_2D,h.TEXTURE_MIN_FILTER,h.LINEAR),h.texParameteri(h.TEXTURE_2D,h.TEXTURE_MAG_FILTER,h.LINEAR),h.texParameteri(h.TEXTURE_2D,h.TEXTURE_WRAP_S,h.CLAMP_TO_EDGE),h.texParameteri(h.TEXTURE_2D,h.TEXTURE_WRAP_T,h.CLAMP_TO_EDGE),V=h.createFramebuffer(),!0)}function ie(){let e=m.value;if(!e||!h)return;let n=e.clientWidth,r=e.clientHeight;e.width=Math.max(1,Math.round(n*t)),e.height=Math.max(1,Math.round(r*t)),U=Math.max(1,Math.round(e.width*N)),W=Math.max(1,Math.round(e.height*N)),h.bindTexture(h.TEXTURE_2D,H),h.texImage2D(h.TEXTURE_2D,0,h.RGBA,U,W,0,h.RGBA,h.UNSIGNED_BYTE,null),h.bindFramebuffer(h.FRAMEBUFFER,V),h.framebufferTexture2D(h.FRAMEBUFFER,h.COLOR_ATTACHMENT0,h.TEXTURE_2D,H,0),h.bindFramebuffer(h.FRAMEBUFFER,null)}function K(e){let t=m.value;G.x+=(G.tx-G.x)*.2,G.y+=(G.ty-G.y)*.2,h.bindFramebuffer(h.FRAMEBUFFER,V),h.viewport(0,0,U,W),h.useProgram(I),h.uniform2f(R.uRes,U,W),h.uniform1f(R.uTime,e),h.uniform1f(R.uSpeed,S),h.uniform1f(R.uDensity,C),h.uniform1f(R.uFrequency,w),h.uniform3f(R.uColor1,n[0],n[1],n[2]),h.uniform3f(R.uColor2,a[0],a[1],a[2]),h.drawArrays(h.TRIANGLES,0,3),h.bindFramebuffer(h.FRAMEBUFFER,null),h.viewport(0,0,t.width,t.height),h.useProgram(L),h.activeTexture(h.TEXTURE0),h.bindTexture(h.TEXTURE_2D,H),h.uniform1i(z.uFluid,0),h.uniform2f(z.uRes,t.width,t.height),h.uniform1f(z.uTime,e),h.uniform2f(z.uMouse,G.x,G.y),h.uniform1f(z.uMouseRadius,k),h.uniform1f(z.uMouseStrength,A),h.drawArrays(h.TRIANGLES,0,3),v||(v=!0,t.classList.add(`is-ready`))}function q(e){g=requestAnimationFrame(q),K((e-_)*.001)}function J(e){let t=m.value;if(!t)return;let n=t.getBoundingClientRect();G.tx=(e.clientX-n.left)/n.width,G.ty=1-(e.clientY-n.top)/n.height}function Y(){G.tx=-10,G.ty=-10}let X=0;function Z(){clearTimeout(X),X=setTimeout(()=>{h&&(ie(),K((performance.now()-_)*.001))},160)}let ae=!0,oe=!0,se=!1;function Q(){let e=!se&&ae&&oe&&!!h;e&&!g?g=requestAnimationFrame(q):!e&&g&&(cancelAnimationFrame(g),g=0)}function ce(){oe=!document.hidden,Q()}let $=null;function le(){let e=m.value;e&&typeof IntersectionObserver<`u`&&($=new IntersectionObserver(e=>{ae=e[e.length-1].isIntersecting,Q()},{rootMargin:`200px 0px`}),$.observe(e))}return r(()=>{let e=window.matchMedia(`(prefers-reduced-motion: reduce)`).matches;if(!re()){h?(h.clearColor(u[0],u[1],u[2],1),h.clear(h.COLOR_BUFFER_BIT),console.info(`[DotMatrix] WebGL2 初始化失败，降级为纯色背景。`)):console.info(`[DotMatrix] 无 WebGL2，背景留空。`);return}if(ie(),e){console.info(`[DotMatrix] 检测到 prefers-reduced-motion，只渲染静态一帧。`),se=!0,K(0);return}_=performance.now(),le(),Q(),window.addEventListener(`pointermove`,J,{passive:!0}),document.addEventListener(`pointerleave`,Y),window.addEventListener(`resize`,Z),document.addEventListener(`visibilitychange`,ce)}),d(()=>{clearTimeout(X),cancelAnimationFrame(g),$&&$.disconnect(),window.removeEventListener(`pointermove`,J),document.removeEventListener(`pointerleave`,Y),window.removeEventListener(`resize`,Z),document.removeEventListener(`visibilitychange`,ce)}),(e,t)=>(i(),p(`canvas`,{ref_key:`canvasRef`,ref:m,class:`dotmatrix`,"aria-hidden":`true`},null,512))}},[[`__scopeId`,`data-v-bb5e9acd`]]),L={class:`container hero__inner`},R={class:`char`},z=`南门拈星`,B=.75,V=m({__name:`HeroSection`,setup(t){let n=[...z],a=o(null),l=0;function f(){l=0;let e=a.value;if(!e)return;let t=window.innerHeight||1,n=Math.min(1,Math.max(0,window.scrollY/(t*B)));e.style.setProperty(`--hero-p`,n.toFixed(3)),e.classList.toggle(`is-frosted`,n>.02)}function m(){l||=requestAnimationFrame(f)}return r(()=>{f(),window.addEventListener(`scroll`,m,{passive:!0}),window.addEventListener(`resize`,m,{passive:!0})}),d(()=>{l&&cancelAnimationFrame(l),window.removeEventListener(`scroll`,m),window.removeEventListener(`resize`,m)}),(t,r)=>(i(),p(`section`,{id:`top`,ref_key:`heroRef`,ref:a,class:`hero`},[r[4]||=h(`div`,{class:`hero__veil`,"aria-hidden":`true`},null,-1),h(`div`,L,[r[0]||=h(`p`,{class:`eyebrow hero__eyebrow`},`量化交易系统`,-1),h(`h1`,{class:`hero__title`,"aria-label":z},[(i(),p(u,null,e(n,(e,t)=>h(`span`,{key:t,class:`char-mask`,style:c({"--i":t}),"aria-hidden":`true`},[h(`span`,R,_(e),1)],4)),64))]),r[1]||=h(`p`,{class:`hero__sub`},[s(` 以数据与工程为底，做安静的量化系统。`),h(`br`),s(` 不喧哗，不承诺，只把该做的事做到毫秒级。 `)],-1),r[2]||=h(`div`,{class:`hero__rule`},null,-1),r[3]||=h(`ul`,{class:`hero__meta`},[h(`li`,null,[h(`span`,null,`架构`),s(`主控 / 跟随端`)]),h(`li`,null,[h(`span`,null,`链路`),s(`命名管道直驱`)]),h(`li`,null,[h(`span`,null,`授权`),s(`离线激活码`)])],-1)]),r[5]||=h(`a`,{class:`hero__cue`,href:`#about`,"aria-label":`向下滚动`},[h(`span`,{class:`hero__cue-line`}),h(`span`,{class:`hero__cue-text`},`SCROLL`)],-1)],512))}},[[`__scopeId`,`data-v-e42dddb2`]]),H={class:`hero-bg`},U=m({__name:`HeroBlock`,setup(e){return(e,t)=>{let n=I,r=V;return i(),p(`div`,H,[g(n),g(r)])}}},[[`__scopeId`,`data-v-4bf14401`]]),W={id:`about`,class:`section about`},G={class:`container`},ee={class:`about__head`},te={class:`container`},ne={class:`stack__top`},re={class:`stack__no`},ie={class:`stack__tag`},K={class:`stack__body`},q={class:`stack__title`},J={class:`stack__desc`},Y=.03,X=m({__name:`AboutSection`,setup(a){let f=[{no:`01`,title:`两端协作`,desc:`主控负责决策与下单，跟随端通过命名管道直驱，把指令送到每一台终端。`,tag:`主控 + 跟随端`},{no:`02`,title:`毫秒级直驱`,desc:`命名管道直连终端，跳过轮询与文件落地，指令以毫秒级送达。`,tag:`命名管道`},{no:`03`,title:`链路在本地`,desc:`全程本地完成，不依赖第三方中转。数据与指令不离开自己的机器。`,tag:`本地链路`},{no:`04`,title:`离线授权`,desc:`离线激活码绑定账号、经纪商与有效期；一次编译即可分发给不同客户。`,tag:`离线激活码`}],m=f.length,g=o(null),v=o([]),y=0,b=1,x=0,S=null,C=!1;function w(){let e=g.value;if(!e)return;let t=e.getBoundingClientRect();y=t.top+window.scrollY,b=Math.max(1,t.height-window.innerHeight)}let T=e=>e<0?0:e>1?1:e;function E(){if(x=0,!C)return;let e=T((window.scrollY-y)/b);for(let t=0;t<m;t++){let n=v.value[t];if(!n)continue;let r=t/m,i=T((e-r)/(1-r||1)),a=1+(1-(m-t)*Y-1)*i;n.style.transform=`scale(${a.toFixed(4)})`}}function D(){!x&&C&&(x=requestAnimationFrame(E))}function O(){w(),D()}return r(()=>{w(),typeof IntersectionObserver<`u`&&g.value?(S=new IntersectionObserver(e=>{C=e[e.length-1].isIntersecting,C&&D()},{rootMargin:`40% 0px`}),S.observe(g.value)):C=!0,window.addEventListener(`scroll`,D,{passive:!0}),window.addEventListener(`resize`,O,{passive:!0}),E()}),d(()=>{x&&cancelAnimationFrame(x),S&&S.disconnect(),window.removeEventListener(`scroll`,D),window.removeEventListener(`resize`,O)}),(r,a)=>{let o=n(`reveal`);return i(),p(`section`,W,[h(`div`,G,[t((i(),p(`div`,ee,[...a[0]||=[h(`p`,{class:`eyebrow rv`},`理念`,-1),h(`h2`,{class:`title rv`},[s(` 把交易执行`),h(`br`),s(` 做到`),h(`em`,null,`安静而准确`)],-1)]])),[[o,{selector:`.rv`,stagger:.1}]])]),h(`div`,te,[h(`div`,{ref_key:`stackRef`,ref:g,class:`stack`},[(i(),p(u,null,e(f,(e,t)=>h(`div`,{key:e.no,class:`stack__item`},[h(`div`,{ref_for:!0,ref:e=>v.value[t]=e,class:`stack__box`,style:c({top:`${5+t*3}%`})},[h(`article`,{class:l([`stack__card`,`stack__card--${t+1}`])},[h(`header`,ne,[h(`span`,re,_(e.no),1),h(`span`,ie,_(e.tag),1)]),h(`div`,K,[h(`h3`,q,_(e.title),1),h(`p`,J,_(e.desc),1)]),a[1]||=h(`span`,{class:`stack__glow`,"aria-hidden":`true`},null,-1)],2)],4)])),64))],512)])])}}},[[`__scopeId`,`data-v-f602b359`]]),Z={id:`capability`,class:`section cap`},ae={class:`container`},oe={class:`cap__head`},se={class:`dt__num`,"aria-hidden":`true`},Q={class:`dt__row`},ce={class:`dt__side`},$={class:`dt__bar`},le={class:`dt__main`},ue={class:`dt__pill`},de={class:`dt__foot`},fe={class:`dt__author-text`},pe={class:`dt__author-name`},me={class:`dt__author-role`},he={class:`dt__media`},ge={class:`dt__media-move`},_e=[`src`,`alt`],ve={class:`dt__nav`},ye={class:`dt__ticker`,"aria-hidden":`true`},be={class:`dt__ticker-track`},xe=`CAPABILITY`,Se=6e3,Ce=4,we=20,Te=.6,Ee=1,De=.78,Oe=m({__name:`CapabilitySection`,setup(l){let m=[{quote:`负责信号判定、仓位管理与下单。所有决策逻辑集中在一处，便于回测与版本管理。`,author:`主控`,role:`风控内置`,company:`策略引擎`,image:`/images/capability/engine.webp`},{quote:`通过命名管道直驱终端，跳过轮询与文件落地，把指令在毫秒级送达每一台机器。`,author:`跟随端`,role:`多端同步`,company:`命名管道`,image:`/images/capability/pipeline.webp`},{quote:`离线激活码，绑定账号、经纪商与有效期。一次编译分发所有客户，按需发码即可。`,author:`授权`,role:`按客户发码`,company:`离线校验`,image:`/images/capability/license.webp`}],y=o(0),b=f(()=>m[y.value]),x=f(()=>String(y.value+1).padStart(2,`0`)),S=f(()=>`${(y.value+1)/m.length*100}%`),C=f(()=>m.map(e=>e.author).join(` • `)+` • `),w=f(()=>b.value.quote.split(/(?<=[，。、；：])/).filter(Boolean).flatMap(e=>e.length<=Ce?[e]:e.match(RegExp(`.{1,${Ce}}`,`g`))||[e])),T=f(()=>{let e=w.value.length;return e>1?Math.min(.05,.3/(e-1)):0}),E=o(null);function D(){j.value=!1}let O=0;function k(){O=0;let e=E.value;if(!e||N.value)return;let t=e.getBoundingClientRect(),n=window.innerHeight||1,r=(n/2-(t.top+t.height/2))/((n+t.height)/2||1),i=r<-1?-1:r>1?1:r,a=Math.max(0,Math.min(1,(i+1)/Te)),o=Math.max(0,Math.min(1,(i+1)/Ee));e.style.setProperty(`--cap-text-y`,`${(-16*i).toFixed(2)}px`),e.style.setProperty(`--cap-media-y`,`${(we*i).toFixed(2)}px`),e.style.setProperty(`--cap-media-o`,a.toFixed(3)),e.style.setProperty(`--cap-media-s`,(De+.21999999999999997*o).toFixed(4))}function A(){O||=requestAnimationFrame(k)}let j=o(!1),M=o(!1),N=o(!1),P=0,F=null;function I(){clearTimeout(P),P=window.setTimeout(()=>{M.value&&!j.value&&(y.value=(y.value+1)%m.length),I()},Se)}function L(e){y.value=(y.value+e+m.length)%m.length,I()}return r(()=>{N.value=window.matchMedia(`(prefers-reduced-motion: reduce)`).matches,typeof IntersectionObserver>`u`?M.value=!0:(F=new IntersectionObserver(e=>{let t=e[e.length-1].isIntersecting;t&&(M.value=!0),j.value=!t},{threshold:.2}),E.value&&F.observe(E.value)),m.forEach(e=>{let t=new Image;t.src=e.image}),k(),window.addEventListener(`scroll`,A,{passive:!0}),window.addEventListener(`resize`,A,{passive:!0}),I()}),d(()=>{clearTimeout(P),clearTimeout(0),O&&cancelAnimationFrame(O),F&&F.disconnect(),window.removeEventListener(`scroll`,A),window.removeEventListener(`resize`,A)}),(r,o)=>{let l=n(`reveal`);return i(),p(`section`,Z,[h(`div`,ae,[t((i(),p(`div`,oe,[...o[5]||=[h(`p`,{class:`eyebrow rv`},`能力`,-1),h(`h2`,{class:`title rv`},`三个部分，一条链路`,-1)]])),[[l,{selector:`.rv`,stagger:.1}]]),h(`div`,{ref_key:`stageRef`,ref:E,class:`dt`,onPointerenter:o[2]||=e=>j.value=!0,onPointerleave:D,onFocusin:o[3]||=e=>j.value=!0,onFocusout:o[4]||=e=>j.value=!1},[h(`div`,se,[g(v,{name:`dt-num`,mode:`out-in`},{default:a(()=>[(i(),p(`span`,{key:y.value,class:`dt__num-in`},_(x.value),1))]),_:1})]),h(`div`,Q,[h(`div`,ce,[h(`span`,{class:`dt__side-title`},_(xe)),h(`div`,$,[h(`div`,{class:`dt__bar-fill`,style:c({height:S.value})},null,4)])]),h(`div`,le,[g(v,{name:`dt-pill`,mode:`out-in`},{default:a(()=>[(i(),p(`div`,{key:y.value,class:`dt__pillwrap`},[h(`span`,ue,[o[6]||=h(`span`,{class:`dt__dot`},null,-1),s(` `+_(b.value.company),1)])]))]),_:1}),g(v,{name:`dt-quote`,mode:`out-in`},{default:a(()=>[(i(),p(`blockquote`,{key:y.value,class:`dt__quote`,style:c({"--step":`${T.value}s`})},[(i(!0),p(u,null,e(w.value,(e,t)=>(i(),p(`span`,{key:`${y.value}-${t}`,class:`dt__word`,style:c({"--i":t})},_(e),5))),128))],4))]),_:1}),h(`div`,de,[g(v,{name:`dt-author`,mode:`out-in`},{default:a(()=>[(i(),p(`div`,{key:y.value,class:`dt__author`},[o[7]||=h(`span`,{class:`dt__author-line`},null,-1),h(`span`,fe,[h(`span`,pe,_(b.value.author),1),h(`span`,me,_(b.value.role),1)])]))]),_:1})])]),h(`div`,he,[h(`div`,ge,[g(v,{name:`dt-media`,mode:`out-in`},{default:a(()=>[(i(),p(`img`,{key:y.value,class:`dt__img`,src:b.value.image,alt:`${b.value.company} 示意图`,width:`1024`,height:`920`,decoding:`async`},null,8,_e))]),_:1})]),h(`div`,ve,[h(`button`,{type:`button`,class:`dt__arrow`,"aria-label":`上一项`,onClick:o[0]||=e=>L(-1)},[...o[8]||=[h(`svg`,{viewBox:`0 0 16 16`,width:`18`,height:`18`,fill:`none`},[h(`path`,{d:`M10 12L6 8L10 4`,stroke:`currentColor`,"stroke-width":`1.5`,"stroke-linecap":`round`,"stroke-linejoin":`round`})],-1)]]),h(`button`,{type:`button`,class:`dt__arrow`,"aria-label":`下一项`,onClick:o[1]||=e=>L(1)},[...o[9]||=[h(`svg`,{viewBox:`0 0 16 16`,width:`18`,height:`18`,fill:`none`},[h(`path`,{d:`M6 4L10 8L6 12`,stroke:`currentColor`,"stroke-width":`1.5`,"stroke-linecap":`round`,"stroke-linejoin":`round`})],-1)]])])])]),h(`div`,ye,[h(`div`,be,[(i(),p(u,null,e(2,e=>h(`span`,{key:e},_(C.value),1)),64))])])],544)])])}}},[[`__scopeId`,`data-v-000085db`]]),ke=`data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARcAAAEXAQAAAACvqD15AAABXUlEQVR42u2avRHCMAyFBRQpPQKjZLQwWkbJCClT5DD6iw1VbHU5nivjU/WdpPekQPn0vAkxiEHMJWIWsjPaJb/GJW3+ljjmTufnn2OUYVKeiu5hVPmibwsYtjLcPP2IGB1N8zMLTMlMMOxkmNdhvzFDfgPDcB4Kw1LUYBjoh6YznIfoh90Miy6bpkCX+xnWc/RDz0z3P2DYVMu7/xq0qPUiCYk87KhltYUzHSX85IS0C/KwtZZNhT392B8KzFLUYNjWD7UNzlRnPX2BprQzXK37jZKQbmngbUL+sDTGoil5Rj9s1hS1NCSznnhs0RTyDok87Jn1ypj8TRW13DkvS9btdnFxgbfpnlNMjg8pAcP4vFwHZ+hyYI/Nv6sttMkFDDv3h+nXbINh7FuA1vJhtsEw8C1Aa5m/p+jkAn8Y2WPbumbSCZqw+wrqspntRReJ2NtE9tj4DwNiEHPVmA8IB0wvguqz1QAAAABJRU5ErkJggg==`,Ae={id:`contact`,class:`section contact`},je={class:`container`},Me={class:`contact__head`},Ne={class:`contact__body`},Pe={class:`steps`},Fe={class:`steps__no`},Ie={class:`steps__main`},Le={class:`steps__title`},Re={class:`steps__desc`},ze={class:`ccard`},Be={class:`ccard__qr`},Ve=[`src`,`alt`],He={class:`ccard__tabs`,role:`tablist`,"aria-label":`联系方式`},Ue=[`aria-selected`,`onClick`],We={class:`ccard__hint`},Ge={class:`ccard__id`},Ke={class:`ccard__label`},qe={class:`ccard__val`},Je=[`disabled`,`aria-label`],Ye=m({__name:`ContactSection`,setup(r){let c=[{key:`wx1`,label:`微信`,hint:`扫码添加微信`,field:`微信号`,value:`XP863131`,qr:ke,copyable:!0},{key:`wx2`,label:`微信`,hint:`扫码添加微信`,field:`微信号`,value:`待补充`,qr:``,copyable:!1},{key:`tg`,label:`Telegram`,hint:`扫码打开 Telegram`,field:`Telegram`,value:`待补充`,qr:``,copyable:!1}],m=o(0),y=f(()=>c[m.value]),b=[{no:`01`,title:`发送信息`,desc:`账号、经纪商与期望的有效期，一条消息说清即可。`},{no:`02`,title:`生成激活码`,desc:`离线校验，绑定账号 / 经纪商 / 有效期，按需发码。`},{no:`03`,title:`交付使用`,desc:`一次编译，全量分发，不需要为每个人改代码。`}],x=o(!1),S=0;async function C(e){try{if(navigator.clipboard?.writeText)return await navigator.clipboard.writeText(e),!0}catch{}try{let t=document.createElement(`textarea`);t.value=e,t.setAttribute(`readonly`,``),t.style.position=`fixed`,t.style.top=`-1000px`,document.body.appendChild(t),t.select();let n=document.execCommand(`copy`);return document.body.removeChild(t),n}catch{return!1}}function w(e){e!==m.value&&(m.value=e,x.value=!1,clearTimeout(S))}async function T(){y.value.copyable&&await C(y.value.value)&&(x.value=!0,clearTimeout(S),S=window.setTimeout(()=>x.value=!1,1600))}return d(()=>clearTimeout(S)),(r,o)=>{let d=n(`reveal`);return i(),p(`section`,Ae,[h(`div`,je,[t((i(),p(`div`,Me,[...o[0]||=[h(`p`,{class:`eyebrow rv`},`联系`,-1),h(`h2`,{class:`title rv`},[s(`要一个自己的`),h(`em`,null,`激活码`),s(`？`)],-1),h(`p`,{class:`lead rv`},` 把账号、经纪商和期望的有效期发过来，我们生成对应的离线激活码。 `,-1)]])),[[d,{selector:`.rv`,stagger:.1}]]),h(`div`,Ne,[t((i(),p(`ol`,Pe,[(i(),p(u,null,e(b,e=>h(`li`,{key:e.no,class:`steps__item`},[h(`span`,Fe,_(e.no),1),h(`div`,Ie,[h(`h3`,Le,_(e.title),1),h(`p`,Re,_(e.desc),1)])])),64))])),[[d,{selector:`.steps__item`,stagger:.09,y:28}]]),t((i(),p(`aside`,ze,[o[2]||=h(`span`,{class:`ccard__dots`,"aria-hidden":`true`},null,-1),o[3]||=h(`span`,{class:`ccard__glow`,"aria-hidden":`true`},null,-1),h(`figure`,Be,[g(v,{name:`q-swap`,mode:`out-in`},{default:a(()=>[y.value.qr?(i(),p(`img`,{key:y.value.key,src:y.value.qr,alt:`${y.value.label}二维码`,width:`279`,height:`279`,loading:`lazy`},null,8,Ve)):(i(),p(`div`,{key:y.value.key,class:`ccard__empty`},[...o[1]||=[h(`span`,null,`二维码待补充`,-1)]]))]),_:1})]),h(`div`,He,[(i(),p(u,null,e(c,(e,t)=>h(`button`,{key:e.key,type:`button`,role:`tab`,class:l([`ccard__tab`,{"is-active":t===m.value}]),"aria-selected":t===m.value,onClick:e=>w(t)},_(e.label),11,Ue)),64))]),h(`p`,We,_(y.value.hint),1),h(`div`,Ge,[h(`span`,Ke,_(y.value.field),1),h(`code`,qe,_(y.value.value),1),h(`button`,{type:`button`,class:l([`ccard__copy`,{"is-done":x.value}]),disabled:!y.value.copyable,"aria-label":y.value.copyable?`复制${y.value.field} ${y.value.value}`:`${y.value.field}待补充`,onClick:T},_(y.value.copyable?x.value?`已复制`:`复制`:`待补充`),11,Je)])])),[[d,{y:40,duration:1.1}]])])])])}}},[[`__scopeId`,`data-v-de43f1c3`]]),Xe={__name:`index`,setup(e){return(e,t)=>{let n=U,r=X,a=Oe,o=Ye;return i(),p(u,null,[g(n),g(r),g(a),g(o)],64)}}};export{Xe as default};